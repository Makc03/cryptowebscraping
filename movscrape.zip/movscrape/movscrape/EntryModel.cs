﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace movscrape
{
    class EntryModel
    {
        // variables  used for recording movie info
        public string Title { get; set; }
        public string Time { get; set; }
        // i copied this from my crypto webscraper, this doesnt serve a purpose here but when i delete the file the entire thing breaks so its just here
    }
}
